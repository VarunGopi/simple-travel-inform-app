package com.example.travelbuddy.Modal;

public class listoptionmodal {
    private String image,name,keyy;

    public listoptionmodal(){}

    public listoptionmodal(String image, String name, String keyy) {
        this.image = image;
        this.name = name;
        this.keyy = keyy;
    }

    public String getImage() {
        return image;
    }

    public String getName() {
        return name;
    }

    public String getKeyy() {
        return keyy;
    }
}
