package com.example.travelbuddy.Modal;

public class Itinerarymodal {
    String image,name;

    public  Itinerarymodal(){}

    public Itinerarymodal(String image, String name) {
        this.image = image;
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public String getName() {
        return name;
    }
}
